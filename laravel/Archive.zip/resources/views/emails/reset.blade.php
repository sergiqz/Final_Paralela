<h1>Password reset</h1>
<p>Please use the code to reset your password.</p>
<h1><b>Code: {{$data}}</b></h1>