<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Divimage extends Model
{
    protected $fillable = ['league_id', 'image'];
}
