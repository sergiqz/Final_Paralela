<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Mail;
use App\Mail\PasswordReset;

class UserController extends Controller
{
    public function register(Request $request){
        
        $request->validate([
            'firstName' => 'bail|required',
            'lastName' => 'bail|required',
            'email' => 'bail|required|email|unique:users',
            'password' => 'bail|required|min:6'
           ],[
            'email.unique' => 'This email is already in use',
            'password.required' => 'Password is required',
            'firstName.required' => 'firstName is required',
            'lastName.required' => 'lastName is required',
        ]);
       

        $plainPassword=$request->password;
        $password=bcrypt($request->password);
        $request->request->add(['password' => $password]);
        // create the user account 
        $created=User::create($request->all());
        $request->request->add(['password' => $plainPassword]);
        // login now..
        return $this->login($request);
        

        
    }
    public function login(Request $request)
    {
        
        $input = $request->only('email', 'password');
        $jwt_token = null;
        if (!$jwt_token = JWTAuth::attempt($input)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid Email or Password',
            ], 401);
        }
        // get the user 
        $user = Auth::user();
        $isProfileUpdated=false;
        if($user->isPicUpdated==1 && $user->isEmailUpdated){
            $isProfileUpdated=true;
            
        }
        $user->isProfileUpdated=$isProfileUpdated;

        return response()->json([
            'success' => true,
            'token' => $jwt_token,
            'user' => $user
        ]);
    }
    public function logout(Request $request)
    {
        if(!User::checkToken($request)){
            return response()->json([
             'message' => 'Token is required',
             'success' => false,
            ],422);
        }
        
        try {
            JWTAuth::invalidate(JWTAuth::parseToken($request->token));
            return response()->json([
                'success' => true,
                'message' => 'User logged out successfully'
            ]);
        } catch (JWTException $exception) {
            return response()->json([
                'success' => false,
                'message' => 'Sorry, the user cannot be logged out'
            ], 500);
        }
    }

    public function getCurrentUser(Request $request){
       if(!User::checkToken($request)){
           return response()->json([
            'message' => 'Token is required'
           ],422);
       }
        
        $user = JWTAuth::parseToken()->authenticate();
       // add isProfileUpdated....
       $isProfileUpdated=false;
        if($user->isPicUpdated==1 && $user->isEmailUpdated){
            $isProfileUpdated=true;
            
        }
        $user->isProfileUpdated=$isProfileUpdated;

        return $user;
    }

    public function update(Request $request){
        $user=$this->getCurrentUser($request);

        /* property can be edited... 
        
            firstName:'',
            lastName:'',
            email:'',
            password:'',
            gender:'', // select option
            age:'',
            playingHand:'', // select option
            racket:'', // this one a select option from a list of rackes 
            phone:'',
            address:"",
            postal:"",
            state:"",
            city:"",
            country:""

            racket array 
            racket:[ 
                'Adidas',
                'Bullpadel',
                'Vibora',
                'Head',
                'Dropshot',
                'Babolat',
                'Nox',
                'Wilson',
                'Prince',
                'Dunlop',
                'Black Crown',
                'Enebe',
                'Just Ten',
                'Power Padel',
                'Vibor-a',
                'Siux',
                'Royal Padel',
                'Oxygen',
                'Eme',
                'Dunlop',
                'Other'
            ],
    
            gender  array 

            Gender :[
            'Male','Female'
            ],

            // hand array
            hand :[
            'Right','Left'
            ],


        

        */






        
        if(!$user){
            return response()->json([
                'success' => false,
                'message' => 'User is not found'
            ]);
        }
        $this->validate($request, [
        
        'email' => 'bail|required|email|unique:users,email,'. $user->id,
         ],[
           'email.unique' => 'This email is already in use',
        ]);
        if($request->password){
            // password is there so change it
            $password=bcrypt($request->password);
            $request->request->add(['password' => $password]);
            $input=$request->all();
        }else{
            $input=$request->except(['password']);
        }
        // check if email is updated... 
        
        $userCurrentEmail=User::where('id', $user->id)->first(['email']);
        
        if($userCurrentEmail->email!=$request->email){ 
            
            $request->request->add(['isEmailUpdated' => 1]);
        }
       
        $input=$request->except(['token']);
        
        $update=User::where('id', $user->id)->update($input);
        $user = User::find($user->id);
        
        $isProfileUpdated=false;
        if($user->isPicUpdated==1 && $user->isEmailUpdated){
            $isProfileUpdated=true;
        }
        
        $user->isProfileUpdated=$isProfileUpdated;

        return response()->json([
            'success' => true,
            'user' => $user
        ],200);
    }
    public function upload(Request $request){
        $user=$this->getCurrentUser($request);
       
       
    
        $png_url = "profile-".time().".jpg";
        $path = base_path().'/uploads/' . $png_url;
        $img = $request->image;
        $img = substr($img, strpos($img, ",")+1);
        $data = base64_decode($img);
        $success = file_put_contents($path, $data);
        User::where('id', $user->id)->update([
            'profilePic' => $png_url,
            'mobile' => 1, 
            'isPicUpdated' => 1, 
            
            
        ]);
        return response()->json([
            'success' => true, 
            'message' => 'Picture has been uploaded successfully!',
            'newImage' => $png_url
        ]);
    }
   
    public function sendEmail(Request $request)
    {
        $email = $request->email;
        $code=$this->createCode($email);
        if(!$code){
            return response()->json([
                'success' => false, 
                'message' => "This email doesn't exist.",
            ]);
        }

        Mail::to($email)
            ->send(new PasswordReset($code));
        return response()->json([
            'success' => true, 
            'message' => 'A password reset code has been sent to your email. Please check your email.',
            
        ]);
        
    }
    public function createCode($email){
        $user = User::where('email', $email)->count();
        if(!$user){
            return false;
        }
        $code = mt_rand(100000, 999999);
        // update the code 
        User::where('email', $email)->update([
            'code' => $code
        ]);
        return $code;
    }
    public function checkCode(Request $request){
        $code = $request->code;
        $user = User::where('code', $code)->first();
        if(!$user){
            return response()->json([
                'success' => false,
                'token' => null,
                'user' => null,
                'message' => 'Invalid code provided.',
            ]);
        }
        $token=JWTAuth::fromUser($user);
        // update the code back to null 
        User::where('code', $code)->update([
            'code' => null
        ]);
        return response()->json([
            'success' => true,
            'token' => $token,
            'user' => $user,
            'message' => 'Please update your password from your profile.',
        ]);
    }

    public function test(){
        return User::first(['firstName']);

}
public function updateUserInfo(Request $request){
    $user=$this->getCurrentUser($request);
    if(!$user){
        return response()->json([
            'success' => false,
            'message' => 'User is not found'
        ]);
    }
    $data = $request->all();
    if($data['profilePic']!=''){ // UPLOAD PICTURE
        
        // $png_url = "profile-".time().".jpg";
        // $path = base_path().'/public/uploads/' . $png_url;
        // $img = $data['profilePic'];
        // $img = substr($img, strpos($img, ",")+1);
        // \Log::info($img);
        // $data = base64_decode($img);
        // $success = file_put_contents($path, $data);
        // // User::where('id', $user->id)->update([
        // //     'profilePic' => $png_url,
        // //     'mobile' => 1, 
        // //     'isPicUpdated' => 1, 
        // // ]);
        // $data['profilePic'] = $png_url; 
        
    }else{
        //unset($data['profilePic']);
    }
    unset($data['token']);

    $updatedUser = User::where('id', $user->id)->update($data);
    $user =  User::find($user->id);

    \Log::info('updatedUser');
    \Log::info($user);
    return response()->json([
        'success' => true, 
        'message' => 'Information has been updated successfully!',
        'user' =>$user
    ]);
}



}


