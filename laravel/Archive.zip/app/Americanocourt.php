<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Americanocourt extends Model
{
    protected $fillable = [
        'tournament_id',
        'courtName' ,
       
    ];
}
