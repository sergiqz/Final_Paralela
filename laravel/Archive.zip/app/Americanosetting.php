<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Americanosetting extends Model
{
    //
}
