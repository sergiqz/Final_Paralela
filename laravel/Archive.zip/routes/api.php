<?php

use Illuminate\Http\Request;

Route::get('/test/one', 'Test@test');

Route::post('/register/player', 'UserController@register');
Route::get('/test/emails', 'UserController@test');
Route::post('/login', 'UserController@login');
Route::get('/user', 'UserController@getCurrentUser');
Route::post('/update', 'UserController@update');
Route::post('/upload', 'UserController@upload');
Route::get('/logout', 'UserController@logout');


// club listing in home screen 
Route::get('/club/listing', 'ClubController@getClubListing');
// club information   using USER ID
Route::get('/get/club-data/{id}', 'ClubController@profileData'); 

//  id is league_id and and uid is user id
Route::get('/club/trdata/{id}/{uid}', 'ClubController@clubTrInfo');

// get data for a single divisions.  id is division id, here lid is league id
Route::get('/club/div/{id}/{lid}/{uid}', 'ClubController@singleDivData');

// add result 
Route::post('/club/add/result', 'AddResultController@addResult');
// edit result
Route::post('/club/edit/result','EditResultController@edit');

// password reset 
Route::post('/reset/password', 'UserController@sendEmail');
Route::post('/check/code', 'UserController@checkCode');




// v 2.0 routes 
// home page
Route::get('/upcoming-matches', 'HomePageController@getUpcomingMatches');

// standing page 
Route::get('/standings/{id}', 'HomePageController@getStandings');

// get matches 
Route::get('/matches/{id}', 'HomePageController@matches');


// GET DIVISION RANKING FOR A DIV 
Route::get('/divRanking/{id}', 'HomePageController@getStandings');
// GET DIVISIONS FOR A TOURNAMENT WITH TROURNAMENT INFO USING TOURNAMENT ID 
Route::get('/tournament-with-div-and-matches/{trId}/{divId}', 'HomePageController@getTrandDiv');

// get matches with rank 
Route::get('/matches-with-rank/{divId}', 'HomePageController@getMatchesWithRank');

// get team stats 
Route::get('/team-stats/{id}', 'HomePageController@teamStats');
Route::get('/player-stats/{id}', 'HomePageController@playerStats');

// GET THE TOURNAMENT INFO => RUNNING AND COMPLETED TOURNAMENTS WITH INVITATIONS AS WELL 

Route::get('/tournaments-listing', 'HomePageController@tournamentListingAndInvitations');
Route::get('/event/{id}', 'HomePageController@eventInfo');
// get tournaments for seasons with own divsion
Route::get('/get-season/{trId}', 'DivSeasonController@getSeasonWithDiv');




// AMERICANO ROUTES 

Route::get('/get-americano-matches/{trId}/{group}', 'AmericanoController@getMatches');


// update user 

Route::post('/update-user', 'UserController@updateUserInfo');